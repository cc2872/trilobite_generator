"""Block 1, item 8 — re-freeze tests/references/*/measure_v2.json from the CURRENT builder + instrument.

    python scripts/refreeze_references.py            # dry run: prints frozen vs current for every reference, writes nothing
    python scripts/refreeze_references.py --write    # overwrites measure_v2.json (and the part STLs) — only after the [DECISION]s

Never run --write before PREREG's [DECISION] lines are resolved; the tag goes on the commit that contains the new files."""
import sys, os, json, glob
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import schema, instrument as I
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WRITE = "--write" in sys.argv
refs = sorted(d for d in glob.glob(os.path.join(ROOT, "tests", "references", "*")) if os.path.exists(os.path.join(d, "measure_v2.json")))
for d in refs:
    name = os.path.basename(d); frozen = json.load(open(os.path.join(d, "measure_v2.json")))
    P = schema.coerce(json.load(open(os.path.join(d, "params.json"))))
    r, B = I.read(P, export_dir=(d if WRITE else None))
    same = (r["limited_by"] == frozen["limited_by"] and r.get("enroll_class") == frozen.get("enroll_class")
            and abs((r.get("theta_joint_deg") or 0) - (frozen.get("theta_joint_deg") or 0)) <= 0.2)
    print(f"{name:14s} frozen {frozen.get('theta_joint_deg')!s:>6} {frozen['limited_by']:8s} {frozen.get('enroll_class')!s:11s} @{frozen.get('bevel_built_deg')} | "
          f"current {r.get('theta_joint_deg')!s:>6} {r['limited_by']:8s} {r.get('enroll_class')!s:11s} @{r.get('bevel_built_deg')}  {'same' if same else 'DIFFERS'}", flush=True)
    if WRITE:
        r["schema_version"] = schema.SCHEMA_VERSION
        json.dump(r, open(os.path.join(d, "measure_v2.json"), "w"), indent=1, default=str)
print("written" if WRITE else "dry run — nothing written")
