"""Block 1, item 5 — gate test for the pleural facet and the ventral doublure (PREREG gate-before-scaling).
Reads each anchor with the structures OFF (identity, = schema 6.1 geometry) and ON, and prints the deltas
against the 0.1 deg noise floor. Writes docs/block1_gate.json.   ~1 min per read."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import schema, instrument as I

ANCHORS = sys.argv[1:] or ["proetida", "corynexochida", "harpetida", "asaphida", "agnostida"]
ON = dict(facetExtent=0.6, facetAngle=45.0, doublureWidth=0.11, vincular=0.8)
KEYS = ["theta_joint_deg", "total_deg", "limited_by", "stopped_by", "enroll_class", "s_tail", "closure_gap_mm", "bevel_built_deg", "unsane_parts", "valid", "reason"]
out = {}
for name in ANCHORS:
    P0 = json.load(open(f"presets/{name}.json"))["params"]
    for tag, extra in (("off", {}), ("on", ON)):
        P = dict(P0, **extra); t = time.time(); r, B = I.read(P)
        out.setdefault(name, {})[tag] = {k: r.get(k) for k in KEYS}; out[name][tag]["seconds"] = round(time.time() - t)
        print(f"{name:14s} {tag:3s} {r.get('theta_joint_deg')!s:>7} {r.get('limited_by')!s:8s} {r.get('enroll_class')!s:11s} pair={r.get('stopped_by')} gap={r.get('gap_mm')} bevel={r.get('bevel_built_deg')} {out[name][tag]['seconds']}s", flush=True)
    a, b = out[name]["off"], out[name]["on"]
    d = (b["theta_joint_deg"] or 0) - (a["theta_joint_deg"] or 0)
    out[name]["delta_deg"] = round(d, 2); out[name]["load_bearing"] = abs(d) > 2 * 0.1 or a["limited_by"] != b["limited_by"] or a["enroll_class"] != b["enroll_class"]
    print(f"   -> delta {d:+.2f} deg   load-bearing: {out[name]['load_bearing']}", flush=True)
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs", "block1_gate.json")
    prev = json.load(open(path)) if os.path.exists(path) else {}
    prev.update(out); json.dump(prev, open(path, "w"), indent=1, default=str)
