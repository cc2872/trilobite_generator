"""Block 1, item 4 — are spines ever the limiting pair? Re-reads the pilot's four anatomy-limited animals
(design idx 0, 5 agnostida; 11 asaphida; 20 corynexochida) with the collision pair recorded, then again with
every spine family zeroed (genalSpine, pygSpine, spineBase, pygMarginal, axialSpine, occipitalSpine, termSpine).
If theta and the pair agree, spines are not limiting. Writes docs/block1_spines.json."""
import sys, os, json, csv, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import schema, instrument as I
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IDX = [int(a) for a in sys.argv[1:]] or [0, 5, 11, 20]
NOSPINE = dict(genalSpine=0.0, pygSpine=0.0, spineBase=0.0, pygMarginal=0.0, axialSpine=0.0, occipitalSpine=0.0, termSpine=0.0)
design = {int(r["design_index"]): r for r in csv.DictReader(open(os.path.join(ROOT, "runs/2026-09-12-h2-pilot/design.csv")))}
out = {}
for i in IDX:
    row = design[i]; P0 = json.loads(row["params"])
    for tag, extra in (("spines", {}), ("nospine", NOSPINE)):
        P = dict(P0, **extra); t = time.time(); r, B = I.read(P)
        sb = r.get("stopped_by") or []
        pair = [f"{B['names'][i]}-{B['names'][j]}" for i, j, *_ in sb[:3]]
        rec = dict(theta=r.get("theta_joint_deg"), limited_by=r.get("limited_by"), pair=pair, enroll_class=r.get("enroll_class"),
                   gap_mm=r.get("closure_gap_mm"), bevel=r.get("bevel_built_deg"), reason=r.get("reason"), seconds=round(time.time() - t))
        out.setdefault(f"{i}:{row['preset']}", {})[tag] = rec
        print(f"idx {i:3d} {row['preset']:14s} {tag:7s} {rec}", flush=True)
json.dump(out, open(os.path.join(ROOT, "docs", "block1_spines.json"), "w"), indent=1, default=str)
